"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { getLatestCheckin } from "@/lib/mood/storage";
import { loadPrefs } from "@/lib/prefs/storage";
import type { FeedDetail, Prefs, Visibility } from "@/lib/prefs/types";

type FriendShare = {
  id: string;
  name: string;
  visibility: Visibility;
  invisibleToday: boolean;
  detail: FeedDetail;
  // Simple shared payload (later: from DB)
  color: "green" | "yellow" | "orange" | "red" | "gray";
  icon: string;
  status: string;
  updatedAtLabel: string;
};

type PingKind = "🫶" | "☕" | "👀";

const PING_KEY = "viora:pings:v1";

const colorDot: Record<string, string> = {
  green: "bg-emerald-500",
  yellow: "bg-yellow-400",
  orange: "bg-orange-500",
  red: "bg-rose-500",
  gray: "bg-zinc-300 dark:bg-zinc-700",
};

function loadPings(): Array<{ at: string; to: string; kind: PingKind }> {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(PING_KEY);
    return raw ? (JSON.parse(raw) as any[]) : [];
  } catch {
    return [];
  }
}

function savePings(rows: Array<{ at: string; to: string; kind: PingKind }>) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PING_KEY, JSON.stringify(rows.slice(0, 25)));
  } catch {}
}

function effectiveVisibility(p: Pick<Prefs, "visibility" | "invisibleToday">): Visibility {
  return p.invisibleToday ? "hidden" : p.visibility;
}

function renderShare(detail: FeedDetail, share: Pick<FriendShare, "icon" | "status">) {
  if (detail === "color") return null;
  if (detail === "icon") return <span className="text-sm">{share.icon}</span>;
  return (
    <span className="truncate text-sm text-zinc-700 dark:text-zinc-200">
      {share.icon} <span className="font-medium">{share.status}</span>
    </span>
  );
}

export function FriendsClient() {
  const [pings, setPings] = useState<Array<{ at: string; to: string; kind: PingKind }>>([]);
  const [prefs, setPrefs] = useState<Prefs | null>(null);

  const friends = useMemo<FriendShare[]>(
    () => [
      {
        id: "a1",
        name: "Nika",
        visibility: "friends",
        invisibleToday: false,
        detail: "text",
        color: "green",
        icon: "🟢",
        status: "Stabilný mód",
        updatedAtLabel: "dnes",
      },
      {
        id: "b2",
        name: "Matej",
        visibility: "friends",
        invisibleToday: false,
        detail: "icon",
        color: "yellow",
        icon: "🟡",
        status: "Kolísavý mód",
        updatedAtLabel: "dnes",
      },
      {
        id: "c3",
        name: "Zuzka",
        visibility: "friends",
        invisibleToday: true,
        detail: "text",
        color: "orange",
        icon: "🟠",
        status: "Napätý mód",
        updatedAtLabel: "včera",
      },
      {
        id: "d4",
        name: "Robo",
        visibility: "hidden",
        invisibleToday: false,
        detail: "text",
        color: "red",
        icon: "🔴",
        status: "Neotravovať",
        updatedAtLabel: "dnes",
      },
    ],
    []
  );

  useEffect(() => {
    setPings(loadPings());
    setPrefs(loadPrefs());
  }, []);

  function sendPing(to: string, kind: PingKind) {
    const row = { at: new Date().toISOString(), to, kind };
    const next = [row, ...pings];
    setPings(next);
    savePings(next);
  }

  const inviteCode = useMemo(() => {
    // deterministic-ish code so it doesn't jump every refresh (but doesn't need to be secure in MVP)
    const base = "viora-" + (typeof window !== "undefined" ? window.location.host : "local");
    let hash = 0;
    for (let i = 0; i < base.length; i++) hash = (hash * 31 + base.charCodeAt(i)) >>> 0;
    return hash.toString(36).slice(0, 8);
  }, []);

  const inviteUrl = useMemo(() => {
    if (typeof window === "undefined") return `/invite/${inviteCode}`;
    return `${window.location.origin}/invite/${inviteCode}`;
  }, [inviteCode]);

  async function copyInvite() {
    try {
      await navigator.clipboard.writeText(inviteUrl);
    } catch {
      // fallback: nothing
    }
  }

  const myLatest = useMemo(() => getLatestCheckin("general"), []);
  const myEffective = prefs ? effectiveVisibility(prefs) : "friends";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold tracking-tight">Priatelia</h1>
        <Link href="/settings" className="text-sm text-zinc-600 hover:underline dark:text-zinc-300">
          Nastavenia
        </Link>
      </div>

      {prefs && myEffective === "hidden" && (
        <div className="rounded-2xl border border-fuchsia-200 bg-white/70 p-4 shadow-sm backdrop-blur dark:border-fuchsia-900/40 dark:bg-zinc-950/40">
          <div className="text-sm font-medium">Si skrytý dnes</div>
          <p className="mt-1 text-sm text-zinc-600 dark:text-zinc-300">
            Tvoje meno sa v feede neukáže. Ľudia budú musieť žiť s neistotou. Strašné.
          </p>
        </div>
      )}

      <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-sm font-medium">Tvoj zdieľaný stav</div>
            <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
              Náhľad toho, čo (v budúcnosti) uvidia priatelia podľa tvojich nastavení.
            </p>
          </div>
          <Link
            href="/checkin"
            className="rounded-full border border-zinc-200 bg-white px-3 py-1 text-xs font-medium hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-950 dark:hover:bg-zinc-900"
          >
            Check-in
          </Link>
        </div>

        <div className="mt-3 flex items-center gap-3">
          <div
            className={[
              "h-3 w-3 rounded-full",
              myEffective === "hidden" ? colorDot.gray : colorDot[myLatest?.result?.color ?? "gray"],
            ].join(" ")}
            aria-hidden
          />
          <div className="min-w-0">
            {myEffective === "hidden" ? (
              <div className="text-sm font-medium">Skryté</div>
            ) : prefs ? (
              <div className="flex items-center gap-2">
                {prefs.detail !== "color" && <span className="text-sm">{myLatest?.result.icon ?? "⚪"}</span>}
                {prefs.detail === "text" ? (
                  <div className="truncate text-sm font-medium">{myLatest?.result.status ?? "Žiadny záznam"}</div>
                ) : (
                  <div className="truncate text-sm font-medium">{myLatest ? "Aktívny" : "Žiadny záznam"}</div>
                )}
              </div>
            ) : (
              <div className="text-sm font-medium">…</div>
            )}
            <div className="truncate text-xs text-zinc-600 dark:text-zinc-300">
              {myLatest ? `${myLatest.result.score}/100 • ${myLatest.dateISO}` : "Sprav check-in, nech je čo zdieľať."}
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
        <div className="text-sm font-medium">Feed</div>
        <div className="mt-3 space-y-2">
          {friends.map((f) => {
            const fEffective = effectiveVisibility({ visibility: f.visibility, invisibleToday: f.invisibleToday });
            const isHidden = fEffective === "hidden";
            return (
              <div
                key={f.id}
                className="flex items-center justify-between rounded-xl border border-zinc-200 bg-white px-3 py-2 dark:border-zinc-800 dark:bg-zinc-950"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <div className={`h-3 w-3 shrink-0 rounded-full ${isHidden ? colorDot.gray : colorDot[f.color]}`} />
                  <div className="min-w-0">
                    <div className="text-sm font-medium">{f.name}</div>
                    <div className="mt-0.5 flex min-w-0 items-center gap-2">
                      {isHidden ? (
                        <span className="text-xs text-zinc-500 dark:text-zinc-400">skryté • {f.updatedAtLabel}</span>
                      ) : (
                        <>
                          {renderShare(f.detail, f)}
                          <span className="text-xs text-zinc-500 dark:text-zinc-400">• {f.updatedAtLabel}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => sendPing(f.name, "🫶")}
                    className="rounded-lg border border-zinc-200 bg-white px-2 py-1 text-sm hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-950 dark:hover:bg-zinc-900"
                    aria-label="Poslať 🫶"
                  >
                    🫶
                  </button>
                  <button
                    type="button"
                    onClick={() => sendPing(f.name, "☕")}
                    className="rounded-lg border border-zinc-200 bg-white px-2 py-1 text-sm hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-950 dark:hover:bg-zinc-900"
                    aria-label="Poslať ☕"
                  >
                    ☕
                  </button>
                  <button
                    type="button"
                    onClick={() => sendPing(f.name, "👀")}
                    className="rounded-lg border border-zinc-200 bg-white px-2 py-1 text-sm hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-950 dark:hover:bg-zinc-900"
                    aria-label="Poslať 👀"
                  >
                    👀
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-xs text-zinc-500 dark:text-zinc-400">
          MVP: toto je demo feed. V ďalšej iterácii pôjde všetko do DB a tvoje nastavenia začnú reálne riadiť, čo vidia ostatní.
        </p>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
        <div className="text-sm font-medium">Pozvať priateľa</div>
        <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-300">
          Skopíruj link a pošli ho človeku, ktorý ťa má rád aj bez semaforu.
        </p>
        <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
          <code className="flex-1 rounded-xl border border-zinc-200 bg-zinc-50 px-3 py-2 text-xs text-zinc-800 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-200">
            {inviteUrl}
          </code>
          <Link
            href={`/invite/${inviteCode}`}
            className="inline-flex items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:hover:bg-zinc-800"
          >
            Otvoriť
          </Link>
          <button
            type="button"
            onClick={copyInvite}
            className="inline-flex rounded-xl bg-zinc-950 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-800 dark:bg-white dark:text-zinc-950 dark:hover:bg-zinc-200"
          >
            Kopírovať
          </button>
        </div>
      </div>

      {pings.length > 0 && (
        <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
          <div className="text-sm font-medium">Posledné pingy</div>
          <div className="mt-3 space-y-1">
            {pings.slice(0, 10).map((p, idx) => (
              <div key={idx} className="text-sm text-zinc-700 dark:text-zinc-200">
                <span className="mr-2">{p.kind}</span>
                <span className="font-medium">{p.to}</span>
                <span className="ml-2 text-xs text-zinc-500 dark:text-zinc-400">
                  {new Date(p.at).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
